#include <iostream>
using namespace std;

class Queue {
private:
    int front, rear, size;
    int* queue;
public:
    Queue(int s) : front(-1), rear(-1), size(s) {
        queue = new int[size];
    }

    void enqueue(int value) {
        if (rear == size - 1) return;
        if (front == -1) front = 0;
        queue[++rear] = value;
    }

    void dequeue() {
        if (front == -1 || front > rear) return;
        front++;
    }

    bool isEmpty() {
        return (front == -1 || front > rear);
    }

    void display() {
        if (isEmpty()) return;
        for (int i = front; i <= rear; i++)
            cout << queue[i] << " ";
        cout << endl;
    }

    ~Queue() {
        delete[] queue;
    }
};

int main() {
    Queue q(5);
    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    q.display();
    q.dequeue();
    q.display();
    return 0;
}

